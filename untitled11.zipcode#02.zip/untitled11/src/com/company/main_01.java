package com.company;
/*Q) Create a more sophisticated Rectangle class than the one you created in Programming
        Challenge 1. This class stores only the Cartesian coordinates of the four corners of the rectangle.
        The constructor calls a set method that accepts four sets of coordinates and verifies that each of
        these is in the first quadrant with no single x- or y-coordinate larger than 20.0. The set method
        also verifies that the supplied coordinates specify a rectan- gle. Provide methods to calculate the
        length, width, perimeter and area. The length is the larger of the two dimensions. Include a
        predicate method isSquare which determines whether the rectangle is a square. Write a program to
        test class Rectangle.*/


         import javax.swing.JOptionPane;
         import java.util.*;

         //1.
       // create
//class CartesianRectangle
  //      that
    //    stores
      //  the 4
        //corners.
        public class main_01 {

             public static void main(String[] args) {


                 //2.declare instance class variables for rectangle of type float
                 //define them
       /* x1,
        x2,
        x3,
        x4,
        y1,
        y2,
        y3,
        y4:*/

                 float x1;
                 float x2;
                 float x3;
                 float x4;
                 float y1;
                 float y2;
                 float y3;
                 float y4;


                 //
                 // 3.define acontructor that willtake 4parameterwith valueto pass
                 //4.
       /* construtor
        calls a set
        method
        that
        accepts
        sets of
        quadrants
        (of x and
        y)
        //5.
        constructor
        verifies
        that each
        of these is
        in the first
        quadrant
        // with
        no single
        x or y
        coordinate
        > 20.0.*/

       //   public main( float x1, float x2, float x3, float x4, float y1, float y2, float y3, float y4)
                 {


            /* int point;
             Object between;
             Object and;
             Object must;
             Object be;*/
                     if (x1 < 00.0f
                             || x1 > 20.0f) {

                         JOptionPane.showMessageDialog(null, " point x1 must be between 1 and 20. You put: " + x1);
                     }

                     if (x2 < 00.0f
                             || x2 > 20.0f) {

                         JOptionPane.showMessageDialog(null, " point x2 must be between 1 and 20. You put: " + x2);
                     }
                     if (x3 < 00.0f
                             || x3 > 20.0f) {
                         //52
                         JOptionPane.showMessageDialog(null, " point x3 must be between 1 and 20. You put: " + x3);
                     }
                     if (x4 < 00.0f
                             || x4 > 20.0f) {

                         JOptionPane.showMessageDialog(null, " point x4 must be between 1 and 20. You put: " + x4);
                     }
                     if (y1 < 00.0f
                             || y1 > 20.0f
                     ) {

                         JOptionPane.showMessageDialog(null, " point y1 must be between 1 and 20. You put: " + y1);
                     }
                     if (y2 < 00.0f
                             || y2 > 20.0f
                     ) {

                         JOptionPane.showMessageDialog(null, " point y2 must be between 1 and 20. You put: " + y2);
                     }
                     if (y3 < 00.0f
                             || y3 > 20.0f
                     ) {

                         JOptionPane.showMessageDialog(null, " point y4 must be between 1 and 20. You put: " + y2);
                     }
                     if (y4 < 00.0f
                             || y4 > 20.0f
                     ) {

                         JOptionPane.showMessageDialog(null, " point y4 must be between 1 and 20. You put: " + y4);
                     }
                 }
             }
         }